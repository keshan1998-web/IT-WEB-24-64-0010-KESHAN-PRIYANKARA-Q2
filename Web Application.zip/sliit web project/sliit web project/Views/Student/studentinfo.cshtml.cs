using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace sliit_web_project.Views.Student
{
    public class studentinfoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
