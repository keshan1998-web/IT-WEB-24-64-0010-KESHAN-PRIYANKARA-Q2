using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace sliit_web_project.Views.Student
{
    public class addstudentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
