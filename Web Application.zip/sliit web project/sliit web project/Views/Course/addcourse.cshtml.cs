using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace sliit_web_project.Views.Course
{
    public class addcourseModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
