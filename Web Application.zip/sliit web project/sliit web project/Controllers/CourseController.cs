﻿using Microsoft.AspNetCore.Mvc;
using sliit_web_project.Models;

namespace sliit_web_project.Controllers
{
    public class CourseController : Controller
    {
        private static List<Course> courses = new List<Course>();

        public ActionResult AddCourse()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddCourse(Course course)
        {
            course.Id = courses.Count + 1;
            courses.Add(course);
            return RedirectToAction("AddCourse");
        }
    }

}
