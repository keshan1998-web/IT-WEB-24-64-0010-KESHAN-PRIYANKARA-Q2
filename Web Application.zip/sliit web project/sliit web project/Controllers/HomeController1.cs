﻿using Microsoft.AspNetCore.Mvc;

namespace sliit_web_project.Controllers
{
    public class HomeController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
