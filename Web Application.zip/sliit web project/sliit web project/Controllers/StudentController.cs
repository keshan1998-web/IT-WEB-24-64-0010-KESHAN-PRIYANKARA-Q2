﻿using Microsoft.AspNetCore.Mvc;
using sliit_web_project.Models;

namespace sliit_web_project.Controllers
{
    public class StudentController : Controller
    {
        private static List<Student> students = new List<Student>();

        public ActionResult AddStudent()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddStudent(Student student)
        {
            student.Id = students.Count + 1;
            students.Add(student);
            return RedirectToAction("StudentInfo");
        }

        public ActionResult StudentInfo()
        {
            ViewBag.Students = students;
            return View();
        }
    }

}
